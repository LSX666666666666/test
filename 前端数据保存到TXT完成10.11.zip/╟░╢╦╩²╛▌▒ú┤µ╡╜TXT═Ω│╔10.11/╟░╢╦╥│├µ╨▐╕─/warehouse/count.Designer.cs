﻿namespace warehouse
{
    partial class count
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_change = new System.Windows.Forms.Panel();
            this.btnplane = new System.Windows.Forms.Button();
            this.btninput = new System.Windows.Forms.Button();
            this.pwarehouse = new System.Windows.Forms.Panel();
            this.alltime = new System.Windows.Forms.Label();
            this.progressBarZT = new System.Windows.Forms.ProgressBar();
            this.progressBarCY = new System.Windows.Forms.ProgressBar();
            this.progressBarDY = new System.Windows.Forms.ProgressBar();
            this.lbCY = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbDY = new System.Windows.Forms.Label();
            this.lbShunXv = new System.Windows.Forms.Label();
            this.btnappoint = new System.Windows.Forms.Button();
            this.btnAll = new System.Windows.Forms.Button();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtnumber = new System.Windows.Forms.TextBox();
            this.lprogress = new System.Windows.Forms.Label();
            this.lorder = new System.Windows.Forms.Label();
            this.lappoint = new System.Windows.Forms.Label();
            this.lbname = new System.Windows.Forms.Label();
            this.lall = new System.Windows.Forms.Label();
            this.lnumber = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.panel_change.SuspendLayout();
            this.pwarehouse.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_change
            // 
            this.panel_change.BackColor = System.Drawing.Color.Silver;
            this.panel_change.Controls.Add(this.btnplane);
            this.panel_change.Controls.Add(this.btninput);
            this.panel_change.Location = new System.Drawing.Point(12, 9);
            this.panel_change.Name = "panel_change";
            this.panel_change.Size = new System.Drawing.Size(178, 755);
            this.panel_change.TabIndex = 1;
            // 
            // btnplane
            // 
            this.btnplane.BackColor = System.Drawing.Color.White;
            this.btnplane.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnplane.Location = new System.Drawing.Point(15, 151);
            this.btnplane.Name = "btnplane";
            this.btnplane.Size = new System.Drawing.Size(144, 45);
            this.btnplane.TabIndex = 0;
            this.btnplane.Text = "仓库平面";
            this.btnplane.UseVisualStyleBackColor = false;
            this.btnplane.Click += new System.EventHandler(this.btnplane_Click);
            // 
            // btninput
            // 
            this.btninput.BackColor = System.Drawing.Color.White;
            this.btninput.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btninput.Location = new System.Drawing.Point(15, 73);
            this.btninput.Name = "btninput";
            this.btninput.Size = new System.Drawing.Size(144, 45);
            this.btninput.TabIndex = 0;
            this.btninput.Text = "参数输入";
            this.btninput.UseVisualStyleBackColor = false;
            this.btninput.Click += new System.EventHandler(this.btninput_Click);
            // 
            // pwarehouse
            // 
            this.pwarehouse.BackColor = System.Drawing.Color.Gainsboro;
            this.pwarehouse.Controls.Add(this.alltime);
            this.pwarehouse.Controls.Add(this.progressBarZT);
            this.pwarehouse.Controls.Add(this.progressBarCY);
            this.pwarehouse.Controls.Add(this.progressBarDY);
            this.pwarehouse.Controls.Add(this.lbCY);
            this.pwarehouse.Controls.Add(this.label1);
            this.pwarehouse.Controls.Add(this.label4);
            this.pwarehouse.Controls.Add(this.label3);
            this.pwarehouse.Controls.Add(this.label2);
            this.pwarehouse.Controls.Add(this.lbDY);
            this.pwarehouse.Controls.Add(this.lbShunXv);
            this.pwarehouse.Controls.Add(this.btnappoint);
            this.pwarehouse.Controls.Add(this.btnAll);
            this.pwarehouse.Controls.Add(this.txtname);
            this.pwarehouse.Controls.Add(this.txtnumber);
            this.pwarehouse.Controls.Add(this.lprogress);
            this.pwarehouse.Controls.Add(this.lorder);
            this.pwarehouse.Controls.Add(this.lappoint);
            this.pwarehouse.Controls.Add(this.lbname);
            this.pwarehouse.Controls.Add(this.lall);
            this.pwarehouse.Controls.Add(this.lnumber);
            this.pwarehouse.Location = new System.Drawing.Point(194, 9);
            this.pwarehouse.Name = "pwarehouse";
            this.pwarehouse.Size = new System.Drawing.Size(1220, 755);
            this.pwarehouse.TabIndex = 4;
            // 
            // alltime
            // 
            this.alltime.AutoSize = true;
            this.alltime.Location = new System.Drawing.Point(842, 91);
            this.alltime.Name = "alltime";
            this.alltime.Size = new System.Drawing.Size(0, 15);
            this.alltime.TabIndex = 6;
            // 
            // progressBarZT
            // 
            this.progressBarZT.Location = new System.Drawing.Point(556, 596);
            this.progressBarZT.Name = "progressBarZT";
            this.progressBarZT.Size = new System.Drawing.Size(455, 27);
            this.progressBarZT.TabIndex = 5;
            // 
            // progressBarCY
            // 
            this.progressBarCY.Location = new System.Drawing.Point(556, 549);
            this.progressBarCY.Name = "progressBarCY";
            this.progressBarCY.Size = new System.Drawing.Size(455, 27);
            this.progressBarCY.TabIndex = 5;
            // 
            // progressBarDY
            // 
            this.progressBarDY.Location = new System.Drawing.Point(556, 502);
            this.progressBarDY.Name = "progressBarDY";
            this.progressBarDY.Size = new System.Drawing.Size(455, 27);
            this.progressBarDY.TabIndex = 5;
            // 
            // lbCY
            // 
            this.lbCY.AutoSize = true;
            this.lbCY.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbCY.Location = new System.Drawing.Point(300, 548);
            this.lbCY.Name = "lbCY";
            this.lbCY.Size = new System.Drawing.Size(208, 28);
            this.lbCY.TabIndex = 4;
            this.lbCY.Text = "货物车运进度：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(300, 596);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(264, 28);
            this.label1.TabIndex = 4;
            this.label1.Text = "整体货物出库进度：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(1069, 595);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 28);
            this.label4.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(1069, 548);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 28);
            this.label3.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(1069, 502);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 28);
            this.label2.TabIndex = 4;
            // 
            // lbDY
            // 
            this.lbDY.AutoSize = true;
            this.lbDY.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbDY.Location = new System.Drawing.Point(302, 501);
            this.lbDY.Name = "lbDY";
            this.lbDY.Size = new System.Drawing.Size(208, 28);
            this.lbDY.TabIndex = 4;
            this.lbDY.Text = "货物吊运进度：";
            // 
            // lbShunXv
            // 
            this.lbShunXv.AutoSize = true;
            this.lbShunXv.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbShunXv.Location = new System.Drawing.Point(302, 433);
            this.lbShunXv.Name = "lbShunXv";
            this.lbShunXv.Size = new System.Drawing.Size(0, 28);
            this.lbShunXv.TabIndex = 4;
            // 
            // btnappoint
            // 
            this.btnappoint.BackColor = System.Drawing.Color.White;
            this.btnappoint.Font = new System.Drawing.Font("黑体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnappoint.Location = new System.Drawing.Point(306, 269);
            this.btnappoint.Name = "btnappoint";
            this.btnappoint.Size = new System.Drawing.Size(489, 48);
            this.btnappoint.TabIndex = 3;
            this.btnappoint.Text = "计算指定货物出库";
            this.btnappoint.UseVisualStyleBackColor = false;
            this.btnappoint.Click += new System.EventHandler(this.btnappoint_Click);
            // 
            // btnAll
            // 
            this.btnAll.BackColor = System.Drawing.Color.White;
            this.btnAll.Font = new System.Drawing.Font("黑体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnAll.Location = new System.Drawing.Point(305, 70);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(489, 48);
            this.btnAll.TabIndex = 3;
            this.btnAll.Text = "计算全部货物出库";
            this.btnAll.UseVisualStyleBackColor = false;
            this.btnAll.Click += new System.EventHandler(this.btnAll_Click);
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(492, 215);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(273, 25);
            this.txtname.TabIndex = 2;
            // 
            // txtnumber
            // 
            this.txtnumber.Location = new System.Drawing.Point(492, 149);
            this.txtnumber.Name = "txtnumber";
            this.txtnumber.Size = new System.Drawing.Size(273, 25);
            this.txtnumber.TabIndex = 2;
            // 
            // lprogress
            // 
            this.lprogress.AutoSize = true;
            this.lprogress.Font = new System.Drawing.Font("黑体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lprogress.Location = new System.Drawing.Point(71, 498);
            this.lprogress.Name = "lprogress";
            this.lprogress.Size = new System.Drawing.Size(163, 30);
            this.lprogress.TabIndex = 1;
            this.lprogress.Text = "出库进度：";
            // 
            // lorder
            // 
            this.lorder.AutoSize = true;
            this.lorder.Font = new System.Drawing.Font("黑体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lorder.Location = new System.Drawing.Point(71, 430);
            this.lorder.Name = "lorder";
            this.lorder.Size = new System.Drawing.Size(223, 30);
            this.lorder.TabIndex = 1;
            this.lorder.Text = "当前出库货物：";
            // 
            // lappoint
            // 
            this.lappoint.AutoSize = true;
            this.lappoint.Font = new System.Drawing.Font("黑体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lappoint.Location = new System.Drawing.Point(72, 144);
            this.lappoint.Name = "lappoint";
            this.lappoint.Size = new System.Drawing.Size(163, 30);
            this.lappoint.TabIndex = 1;
            this.lappoint.Text = "指定货物：";
            // 
            // lbname
            // 
            this.lbname.AutoSize = true;
            this.lbname.Font = new System.Drawing.Font("黑体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbname.Location = new System.Drawing.Point(303, 215);
            this.lbname.Name = "lbname";
            this.lbname.Size = new System.Drawing.Size(194, 25);
            this.lbname.TabIndex = 1;
            this.lbname.Text = "指定货物编号：";
            // 
            // lall
            // 
            this.lall.AutoSize = true;
            this.lall.Font = new System.Drawing.Font("黑体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lall.Location = new System.Drawing.Point(71, 80);
            this.lall.Name = "lall";
            this.lall.Size = new System.Drawing.Size(163, 30);
            this.lall.TabIndex = 1;
            this.lall.Text = "全部货物：";
            // 
            // lnumber
            // 
            this.lnumber.AutoSize = true;
            this.lnumber.Font = new System.Drawing.Font("黑体", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lnumber.Location = new System.Drawing.Point(303, 149);
            this.lnumber.Name = "lnumber";
            this.lnumber.Size = new System.Drawing.Size(194, 25);
            this.lnumber.TabIndex = 1;
            this.lnumber.Text = "指定货物数量：";
            // 
            // count
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1427, 774);
            this.Controls.Add(this.pwarehouse);
            this.Controls.Add(this.panel_change);
            this.Name = "count";
            this.Text = "计算";
            this.panel_change.ResumeLayout(false);
            this.pwarehouse.ResumeLayout(false);
            this.pwarehouse.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_change;
        private System.Windows.Forms.Button btnplane;
        private System.Windows.Forms.Button btninput;
        private System.Windows.Forms.Panel pwarehouse;
        private System.Windows.Forms.TextBox txtnumber;
        private System.Windows.Forms.Label lall;
        private System.Windows.Forms.Label lnumber;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Label lappoint;
        private System.Windows.Forms.Button btnappoint;
        private System.Windows.Forms.Label lprogress;
        private System.Windows.Forms.Label lorder;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lbname;
        private System.Windows.Forms.Label lbShunXv;
        private System.Windows.Forms.ProgressBar progressBarCY;
        private System.Windows.Forms.ProgressBar progressBarDY;
        private System.Windows.Forms.Label lbCY;
        private System.Windows.Forms.Label lbDY;
        private System.Windows.Forms.ProgressBar progressBarZT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label alltime;
        private System.Windows.Forms.Timer timer4;
    }
}