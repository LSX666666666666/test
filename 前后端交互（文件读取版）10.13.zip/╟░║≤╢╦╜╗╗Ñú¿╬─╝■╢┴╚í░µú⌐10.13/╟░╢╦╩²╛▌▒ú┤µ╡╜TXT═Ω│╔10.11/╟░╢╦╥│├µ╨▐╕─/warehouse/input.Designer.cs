﻿namespace warehouse
{
    partial class input
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_change = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btncount = new System.Windows.Forms.Button();
            this.la = new System.Windows.Forms.Label();
            this.txta = new System.Windows.Forms.TextBox();
            this.lb = new System.Windows.Forms.Label();
            this.txtb = new System.Windows.Forms.TextBox();
            this.pwarehouse = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.txtc = new System.Windows.Forms.TextBox();
            this.txtv2 = new System.Windows.Forms.TextBox();
            this.txtD4 = new System.Windows.Forms.TextBox();
            this.txtv1 = new System.Windows.Forms.TextBox();
            this.txtf = new System.Windows.Forms.TextBox();
            this.txth = new System.Windows.Forms.TextBox();
            this.txte = new System.Windows.Forms.TextBox();
            this.txtt2 = new System.Windows.Forms.TextBox();
            this.txtN = new System.Windows.Forms.TextBox();
            this.txtt1 = new System.Windows.Forms.TextBox();
            this.txtg = new System.Windows.Forms.TextBox();
            this.txtfai = new System.Windows.Forms.TextBox();
            this.txtd = new System.Windows.Forms.TextBox();
            this.lgoods = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lroad = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lv2 = new System.Windows.Forms.Label();
            this.lable1 = new System.Windows.Forms.Label();
            this.lD4 = new System.Windows.Forms.Label();
            this.lv1 = new System.Windows.Forms.Label();
            this.lbwarehouse = new System.Windows.Forms.Label();
            this.lf = new System.Windows.Forms.Label();
            this.lc = new System.Windows.Forms.Label();
            this.lt2 = new System.Windows.Forms.Label();
            this.lh = new System.Windows.Forms.Label();
            this.lN = new System.Windows.Forms.Label();
            this.lt1 = new System.Windows.Forms.Label();
            this.lg = new System.Windows.Forms.Label();
            this.le = new System.Windows.Forms.Label();
            this.lfai = new System.Windows.Forms.Label();
            this.ld = new System.Windows.Forms.Label();
            this.panel_change.SuspendLayout();
            this.pwarehouse.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_change
            // 
            this.panel_change.BackColor = System.Drawing.Color.Silver;
            this.panel_change.Controls.Add(this.button1);
            this.panel_change.Controls.Add(this.btncount);
            this.panel_change.Location = new System.Drawing.Point(11, 11);
            this.panel_change.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel_change.Name = "panel_change";
            this.panel_change.Size = new System.Drawing.Size(200, 906);
            this.panel_change.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(17, 181);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 54);
            this.button1.TabIndex = 0;
            this.button1.Text = "仓库平面";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btncount
            // 
            this.btncount.BackColor = System.Drawing.Color.White;
            this.btncount.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btncount.Location = new System.Drawing.Point(17, 88);
            this.btncount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btncount.Name = "btncount";
            this.btncount.Size = new System.Drawing.Size(162, 54);
            this.btncount.TabIndex = 0;
            this.btncount.Text = "计算";
            this.btncount.UseVisualStyleBackColor = false;
            this.btncount.Click += new System.EventHandler(this.btncount_Click);
            // 
            // la
            // 
            this.la.AutoSize = true;
            this.la.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.la.Location = new System.Drawing.Point(166, 54);
            this.la.Name = "la";
            this.la.Size = new System.Drawing.Size(131, 22);
            this.la.TabIndex = 1;
            this.la.Text = "仓库边长a：";
            // 
            // txta
            // 
            this.txta.Location = new System.Drawing.Point(307, 47);
            this.txta.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txta.Name = "txta";
            this.txta.Size = new System.Drawing.Size(174, 28);
            this.txta.TabIndex = 2;
            // 
            // lb
            // 
            this.lb.AutoSize = true;
            this.lb.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb.Location = new System.Drawing.Point(503, 49);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(131, 22);
            this.lb.TabIndex = 1;
            this.lb.Text = "仓库边长b：";
            // 
            // txtb
            // 
            this.txtb.Location = new System.Drawing.Point(644, 47);
            this.txtb.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtb.Name = "txtb";
            this.txtb.Size = new System.Drawing.Size(174, 28);
            this.txtb.TabIndex = 2;
            // 
            // pwarehouse
            // 
            this.pwarehouse.BackColor = System.Drawing.Color.Gainsboro;
            this.pwarehouse.Controls.Add(this.button2);
            this.pwarehouse.Controls.Add(this.txtc);
            this.pwarehouse.Controls.Add(this.txtv2);
            this.pwarehouse.Controls.Add(this.txtD4);
            this.pwarehouse.Controls.Add(this.txtv1);
            this.pwarehouse.Controls.Add(this.txtf);
            this.pwarehouse.Controls.Add(this.txth);
            this.pwarehouse.Controls.Add(this.txte);
            this.pwarehouse.Controls.Add(this.txtt2);
            this.pwarehouse.Controls.Add(this.txtN);
            this.pwarehouse.Controls.Add(this.txtt1);
            this.pwarehouse.Controls.Add(this.txtg);
            this.pwarehouse.Controls.Add(this.txtfai);
            this.pwarehouse.Controls.Add(this.txtd);
            this.pwarehouse.Controls.Add(this.lgoods);
            this.pwarehouse.Controls.Add(this.txta);
            this.pwarehouse.Controls.Add(this.label15);
            this.pwarehouse.Controls.Add(this.label8);
            this.pwarehouse.Controls.Add(this.lroad);
            this.pwarehouse.Controls.Add(this.label5);
            this.pwarehouse.Controls.Add(this.txtb);
            this.pwarehouse.Controls.Add(this.lv2);
            this.pwarehouse.Controls.Add(this.lable1);
            this.pwarehouse.Controls.Add(this.lD4);
            this.pwarehouse.Controls.Add(this.lv1);
            this.pwarehouse.Controls.Add(this.lbwarehouse);
            this.pwarehouse.Controls.Add(this.lf);
            this.pwarehouse.Controls.Add(this.lc);
            this.pwarehouse.Controls.Add(this.lt2);
            this.pwarehouse.Controls.Add(this.lh);
            this.pwarehouse.Controls.Add(this.lN);
            this.pwarehouse.Controls.Add(this.lt1);
            this.pwarehouse.Controls.Add(this.la);
            this.pwarehouse.Controls.Add(this.lg);
            this.pwarehouse.Controls.Add(this.le);
            this.pwarehouse.Controls.Add(this.lfai);
            this.pwarehouse.Controls.Add(this.lb);
            this.pwarehouse.Controls.Add(this.ld);
            this.pwarehouse.Location = new System.Drawing.Point(218, 11);
            this.pwarehouse.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pwarehouse.Name = "pwarehouse";
            this.pwarehouse.Size = new System.Drawing.Size(1372, 906);
            this.pwarehouse.TabIndex = 3;
            this.pwarehouse.Paint += new System.Windows.Forms.PaintEventHandler(this.pwarehouse_Paint);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(507, 538);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(154, 66);
            this.button2.TabIndex = 3;
            this.button2.Text = "保存";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtc
            // 
            this.txtc.Location = new System.Drawing.Point(363, 110);
            this.txtc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtc.Name = "txtc";
            this.txtc.Size = new System.Drawing.Size(174, 28);
            this.txtc.TabIndex = 2;
            // 
            // txtv2
            // 
            this.txtv2.Location = new System.Drawing.Point(1114, 349);
            this.txtv2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtv2.Name = "txtv2";
            this.txtv2.Size = new System.Drawing.Size(174, 28);
            this.txtv2.TabIndex = 2;
            // 
            // txtD4
            // 
            this.txtD4.Location = new System.Drawing.Point(978, 416);
            this.txtD4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtD4.Name = "txtD4";
            this.txtD4.Size = new System.Drawing.Size(174, 28);
            this.txtD4.TabIndex = 2;
            // 
            // txtv1
            // 
            this.txtv1.Location = new System.Drawing.Point(1114, 296);
            this.txtv1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtv1.Name = "txtv1";
            this.txtv1.Size = new System.Drawing.Size(174, 28);
            this.txtv1.TabIndex = 2;
            this.txtv1.TextChanged += new System.EventHandler(this.txtv1_TextChanged);
            // 
            // txtf
            // 
            this.txtf.Location = new System.Drawing.Point(960, 241);
            this.txtf.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtf.Name = "txtf";
            this.txtf.Size = new System.Drawing.Size(174, 28);
            this.txtf.TabIndex = 2;
            // 
            // txth
            // 
            this.txth.Location = new System.Drawing.Point(960, 188);
            this.txth.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txth.Name = "txth";
            this.txth.Size = new System.Drawing.Size(174, 28);
            this.txth.TabIndex = 2;
            // 
            // txte
            // 
            this.txte.Location = new System.Drawing.Point(1114, 114);
            this.txte.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txte.Name = "txte";
            this.txte.Size = new System.Drawing.Size(174, 28);
            this.txte.TabIndex = 2;
            // 
            // txtt2
            // 
            this.txtt2.Location = new System.Drawing.Point(623, 348);
            this.txtt2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtt2.Name = "txtt2";
            this.txtt2.Size = new System.Drawing.Size(174, 28);
            this.txtt2.TabIndex = 2;
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(556, 415);
            this.txtN.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(174, 28);
            this.txtN.TabIndex = 2;
            // 
            // txtt1
            // 
            this.txtt1.Location = new System.Drawing.Point(623, 295);
            this.txtt1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtt1.Name = "txtt1";
            this.txtt1.Size = new System.Drawing.Size(174, 28);
            this.txtt1.TabIndex = 2;
            // 
            // txtg
            // 
            this.txtg.Location = new System.Drawing.Point(537, 240);
            this.txtg.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtg.Name = "txtg";
            this.txtg.Size = new System.Drawing.Size(174, 28);
            this.txtg.TabIndex = 2;
            // 
            // txtfai
            // 
            this.txtfai.Location = new System.Drawing.Point(537, 187);
            this.txtfai.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtfai.Name = "txtfai";
            this.txtfai.Size = new System.Drawing.Size(174, 28);
            this.txtfai.TabIndex = 2;
            // 
            // txtd
            // 
            this.txtd.Location = new System.Drawing.Point(794, 110);
            this.txtd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtd.Name = "txtd";
            this.txtd.Size = new System.Drawing.Size(174, 28);
            this.txtd.TabIndex = 2;
            // 
            // lgoods
            // 
            this.lgoods.AutoSize = true;
            this.lgoods.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lgoods.Location = new System.Drawing.Point(16, 178);
            this.lgoods.Name = "lgoods";
            this.lgoods.Size = new System.Drawing.Size(117, 33);
            this.lgoods.TabIndex = 1;
            this.lgoods.Text = "货物：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label15.Location = new System.Drawing.Point(166, 409);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(180, 28);
            this.label15.TabIndex = 1;
            this.label15.Text = "货物车运输量";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(166, 292);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(180, 28);
            this.label8.TabIndex = 1;
            this.label8.Text = "货物移动速度";
            // 
            // lroad
            // 
            this.lroad.AutoSize = true;
            this.lroad.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lroad.Location = new System.Drawing.Point(16, 108);
            this.lroad.Name = "lroad";
            this.lroad.Size = new System.Drawing.Size(168, 33);
            this.lroad.TabIndex = 1;
            this.lroad.Text = "运输路线:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(166, 235);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 28);
            this.label5.TabIndex = 1;
            this.label5.Text = "货物间距";
            // 
            // lv2
            // 
            this.lv2.AutoSize = true;
            this.lv2.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lv2.Location = new System.Drawing.Point(973, 356);
            this.lv2.Name = "lv2";
            this.lv2.Size = new System.Drawing.Size(131, 22);
            this.lv2.TabIndex = 1;
            this.lv2.Text = "车运速度v2:";
            // 
            // lable1
            // 
            this.lable1.AutoSize = true;
            this.lable1.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lable1.Location = new System.Drawing.Point(166, 184);
            this.lable1.Name = "lable1";
            this.lable1.Size = new System.Drawing.Size(124, 28);
            this.lable1.TabIndex = 1;
            this.lable1.Text = "货物边长";
            // 
            // lD4
            // 
            this.lD4.AutoSize = true;
            this.lD4.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lD4.Location = new System.Drawing.Point(782, 422);
            this.lD4.Name = "lD4";
            this.lD4.Size = new System.Drawing.Size(153, 22);
            this.lD4.TabIndex = 1;
            this.lD4.Text = "前后车距离D4:";
            // 
            // lv1
            // 
            this.lv1.AutoSize = true;
            this.lv1.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lv1.Location = new System.Drawing.Point(973, 304);
            this.lv1.Name = "lv1";
            this.lv1.Size = new System.Drawing.Size(131, 22);
            this.lv1.TabIndex = 1;
            this.lv1.Text = "吊运速度v1:";
            // 
            // lbwarehouse
            // 
            this.lbwarehouse.AutoSize = true;
            this.lbwarehouse.Font = new System.Drawing.Font("黑体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbwarehouse.Location = new System.Drawing.Point(16, 43);
            this.lbwarehouse.Name = "lbwarehouse";
            this.lbwarehouse.Size = new System.Drawing.Size(117, 33);
            this.lbwarehouse.TabIndex = 1;
            this.lbwarehouse.Text = "仓库：";
            // 
            // lf
            // 
            this.lf.AutoSize = true;
            this.lf.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lf.Location = new System.Drawing.Point(849, 248);
            this.lf.Name = "lf";
            this.lf.Size = new System.Drawing.Size(87, 22);
            this.lf.TabIndex = 1;
            this.lf.Text = "边界f：";
            // 
            // lc
            // 
            this.lc.AutoSize = true;
            this.lc.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lc.Location = new System.Drawing.Point(166, 115);
            this.lc.Name = "lc";
            this.lc.Size = new System.Drawing.Size(197, 22);
            this.lc.TabIndex = 1;
            this.lc.Text = "主运输路线距离c：";
            // 
            // lt2
            // 
            this.lt2.AutoSize = true;
            this.lt2.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lt2.Location = new System.Drawing.Point(370, 350);
            this.lt2.Name = "lt2";
            this.lt2.Size = new System.Drawing.Size(241, 22);
            this.lt2.TabIndex = 1;
            this.lt2.Text = "货物吊运转车运时间t2:";
            // 
            // lh
            // 
            this.lh.AutoSize = true;
            this.lh.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lh.Location = new System.Drawing.Point(849, 196);
            this.lh.Name = "lh";
            this.lh.Size = new System.Drawing.Size(87, 22);
            this.lh.TabIndex = 1;
            this.lh.Text = "高度h：";
            // 
            // lN
            // 
            this.lN.AutoSize = true;
            this.lN.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lN.Location = new System.Drawing.Point(370, 416);
            this.lN.Name = "lN";
            this.lN.Size = new System.Drawing.Size(164, 22);
            this.lN.TabIndex = 1;
            this.lN.Text = "货物车运数量N:";
            // 
            // lt1
            // 
            this.lt1.AutoSize = true;
            this.lt1.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lt1.Location = new System.Drawing.Point(370, 298);
            this.lt1.Name = "lt1";
            this.lt1.Size = new System.Drawing.Size(241, 22);
            this.lt1.TabIndex = 1;
            this.lt1.Text = "货物静止转吊运时间t1:";
            // 
            // lg
            // 
            this.lg.AutoSize = true;
            this.lg.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lg.Location = new System.Drawing.Point(415, 241);
            this.lg.Name = "lg";
            this.lg.Size = new System.Drawing.Size(120, 22);
            this.lg.TabIndex = 1;
            this.lg.Text = "货物间距g:";
            // 
            // le
            // 
            this.le.AutoSize = true;
            this.le.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.le.Location = new System.Drawing.Point(986, 118);
            this.le.Name = "le";
            this.le.Size = new System.Drawing.Size(131, 22);
            this.le.TabIndex = 1;
            this.le.Text = "路线宽度e：";
            // 
            // lfai
            // 
            this.lfai.AutoSize = true;
            this.lfai.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lfai.Location = new System.Drawing.Point(415, 188);
            this.lfai.Name = "lfai";
            this.lfai.Size = new System.Drawing.Size(87, 22);
            this.lfai.TabIndex = 1;
            this.lfai.Text = "直径φ:";
            // 
            // ld
            // 
            this.ld.AutoSize = true;
            this.ld.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ld.Location = new System.Drawing.Point(551, 115);
            this.ld.Name = "ld";
            this.ld.Size = new System.Drawing.Size(241, 22);
            this.ld.TabIndex = 1;
            this.ld.Text = "第二条运输路线距离d：";
            // 
            // input
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1605, 929);
            this.Controls.Add(this.pwarehouse);
            this.Controls.Add(this.panel_change);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "input";
            this.Text = "参数输入";
            this.panel_change.ResumeLayout(false);
            this.pwarehouse.ResumeLayout(false);
            this.pwarehouse.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_change;
        private System.Windows.Forms.Label la;
        private System.Windows.Forms.TextBox txta;
        private System.Windows.Forms.Label lb;
        private System.Windows.Forms.TextBox txtb;
        private System.Windows.Forms.Panel pwarehouse;
        private System.Windows.Forms.TextBox txtc;
        private System.Windows.Forms.TextBox txth;
        private System.Windows.Forms.TextBox txte;
        private System.Windows.Forms.TextBox txtfai;
        private System.Windows.Forms.TextBox txtd;
        private System.Windows.Forms.Label lgoods;
        private System.Windows.Forms.Label lroad;
        private System.Windows.Forms.Label lable1;
        private System.Windows.Forms.Label lbwarehouse;
        private System.Windows.Forms.Label lc;
        private System.Windows.Forms.Label lh;
        private System.Windows.Forms.Label le;
        private System.Windows.Forms.Label lfai;
        private System.Windows.Forms.Label ld;
        private System.Windows.Forms.TextBox txtv2;
        private System.Windows.Forms.TextBox txtD4;
        private System.Windows.Forms.TextBox txtv1;
        private System.Windows.Forms.TextBox txtf;
        private System.Windows.Forms.TextBox txtt2;
        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.TextBox txtt1;
        private System.Windows.Forms.TextBox txtg;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lv2;
        private System.Windows.Forms.Label lD4;
        private System.Windows.Forms.Label lv1;
        private System.Windows.Forms.Label lf;
        private System.Windows.Forms.Label lt2;
        private System.Windows.Forms.Label lN;
        private System.Windows.Forms.Label lt1;
        private System.Windows.Forms.Label lg;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btncount;
        private System.Windows.Forms.Button button2;
    }
}

