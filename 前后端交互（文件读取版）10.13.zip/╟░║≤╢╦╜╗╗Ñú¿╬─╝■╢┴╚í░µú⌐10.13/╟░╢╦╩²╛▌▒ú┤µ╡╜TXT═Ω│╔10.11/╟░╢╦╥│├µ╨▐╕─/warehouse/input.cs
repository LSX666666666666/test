﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace warehouse
{
    public partial class input : Form
    {
        //在 input 窗体中，我们可以添加一个静态实例，确保整个应用程序中只有一个 input 实例存在。
        public static input Instance { get; private set; }

        public input()
        {
            InitializeComponent();
            Instance = this;
        }
        
        public string InputtxtaContent
        {
            get { return txta.Text;}
        }
        public string InputtxtbContent
        {
            get { return txtb.Text; }
        }
        public string InputtxtcContent
        {
            get { return txtc.Text; }
        }
        public string InputtxtdContent
        {
            get { return txtd.Text; }
        }
        public string InputtxteContent
        {
            get { return txte.Text; }
        }
        public string InputtxtfContent
        {
            get { return txtf.Text; }
        }
        public string InputtxtgContent
        {
            get { return txtg.Text; }
        }
        public string InputtxtfiContent
        {
            get { return txtfai.Text; }
        }
        public string InputtxthContent
        {
            get { return txth.Text; }
        }
        public string InputtxtcarnContent
        {
            get { return txtN.Text; }
        }
        public string InputtxtcarLContent
        {
            get { return txtD4.Text; }
        }
       



        /*
        public input()
        {
            InitializeComponent();
        }
        */

        private void button1_Click(object sender, EventArgs e)
        {
            
            //当点击按钮从 input 跳转到 plane 或 count 时，不再需要创建新的实例，而是使用已有的实例。-李圣贤
            plane pp = new plane();
            pp.Show();
            this.Hide();
            /*plane pp = new plane(this);
            pp.Show();
            this.Hide();*/
        }

        private void btncount_Click(object sender, EventArgs e)
        {
            /*
            count cc = new count(this);
            cc.Show();
            this.Hide();*/
            count cc = new count();
            cc.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 读取各个属性的值
            string txtaValue = InputtxtaContent;
            string txtbValue = InputtxtbContent;
            string txtcValue = InputtxtcContent;
            string txtdValue = InputtxtdContent;
            string txteValue = InputtxteContent;
            string txtfValue = InputtxtfContent;
            string txtgValue = InputtxtgContent;
            string txtfaiValue = InputtxtfiContent;
            string txthValue = InputtxthContent;
            string txtNValue = InputtxtcarnContent;
            string txtD4Value = InputtxtcarLContent;
           

            // 指定保存文件的路径
            string filePath = "前端数据保存.txt";

            // 将这些值写入文本文件
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine("txta: " + txtaValue);
                writer.WriteLine("txtb: " + txtbValue);
                writer.WriteLine("txtc: " + txtcValue);
                writer.WriteLine("txtd: " + txtdValue);
                writer.WriteLine("txte: " + txteValue);
                writer.WriteLine("txtf: " + txtfValue);
                writer.WriteLine("txtg: " + txtgValue);
                writer.WriteLine("txtfai: " + txtfaiValue);
                writer.WriteLine("txth: " + txthValue);
                writer.WriteLine("txtN: " + txtNValue);
                writer.WriteLine("txtD4: " + txtD4Value);
            }

            MessageBox.Show("值已保存到文件 " + filePath);
        }

        private void pwarehouse_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtv1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
