﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;

namespace warehouse
{
    public partial class input : Form
    {
        //在 input 窗体中，我们可以添加一个静态实例，确保整个应用程序中只有一个 input 实例存在。
        public static input Instance { get; private set; }

        public input()
        {
            InitializeComponent();
            Instance = this;
        }
        
        public string InputtxtaContent
        {
            get { return txta.Text;}
        }
        public string InputtxtbContent
        {
            get { return txtb.Text; }
        }
        public string InputtxtcContent
        {
            get { return txtc.Text; }
        }
        public string InputtxtdContent
        {
            get { return txtd.Text; }
        }
        public string InputtxteContent
        {
            get { return txte.Text; }
        }
        public string InputtxtfContent
        {
            get { return txtf.Text; }
        }
        public string InputtxtgContent
        {
            get { return txtg.Text; }
        }
        public string InputtxtfiContent
        {
            get { return txtfai.Text; }
        }
        public string InputtxthContent
        {
            get { return txth.Text; }
        }
        public string InputtxtcarnContent
        {
            get { return txtN.Text; }
        }
        public string InputtxtcarLContent
        {
            get { return txtD4.Text; }
        }
       



        /*
        public input()
        {
            InitializeComponent();
        }
        */

        private void button1_Click(object sender, EventArgs e)
        {
            
            //当点击按钮从 input 跳转到 plane 或 count 时，不再需要创建新的实例，而是使用已有的实例。-李圣贤
            plane pp = new plane();
            pp.Show();
            this.Hide();
            /*plane pp = new plane(this);
            pp.Show();
            this.Hide();*/
        }

        private void btncount_Click(object sender, EventArgs e)
        {
            /*
            count cc = new count(this);
            cc.Show();
            this.Hide();*/
            count cc = new count();
            cc.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 读取各个属性的值
            string txtaValue = InputtxtaContent;
            string txtbValue = InputtxtbContent;
            string txtcValue = InputtxtcContent;
            string txtdValue = InputtxtdContent;
            string txteValue = InputtxteContent;
            string txtfValue = InputtxtfContent;
            string txtgValue = InputtxtgContent;
            string txtfaiValue = InputtxtfiContent;
            string txthValue = InputtxthContent;
            string txtNValue = InputtxtcarnContent;
            string txtD4Value = InputtxtcarLContent;
           

            // 指定保存文件的路径
            string filePath = "前端数据保存.txt";

            // 将这些值写入文本文件
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine("txta: " + txtaValue);
                writer.WriteLine("txtb: " + txtbValue);
                writer.WriteLine("txtc: " + txtcValue);
                writer.WriteLine("txtd: " + txtdValue);
                writer.WriteLine("txte: " + txteValue);
                writer.WriteLine("txtf: " + txtfValue);
                writer.WriteLine("txtg: " + txtgValue);
                writer.WriteLine("txtfai: " + txtfaiValue);
                writer.WriteLine("txth: " + txthValue);
                writer.WriteLine("txtN: " + txtNValue);
                writer.WriteLine("txtD4: " + txtD4Value);
            }

            MessageBox.Show("值已保存到文件 " + filePath);


            // 定义连接字符串，用于连接数据库
            string connectionString = "server=127.0.0.1;database=date3;user=admin4;password=123456";

            // 使用 using 语句管理数据库连接资源
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                // 打开数据库连接
                connection.Open();

                //要确保后端读取的内容是最新保存的前端数据，要把之前保存的数据清空之后，再写入现在前端输入的数据。
                // 创建并执行 SQL 删除命令，清空之前的数据库内容
                using (MySqlCommand deleteCmd = new MySqlCommand("DELETE FROM date3", connection))
                {
                    // 执行 SQL 删除命令
                    deleteCmd.ExecuteNonQuery();
                }

                // 创建并执行 SQL 插入命令，这里的表名已经更改为 date3，列名也对应调整
                using (MySqlCommand cmd = new MySqlCommand("INSERT INTO date3 (txta, txtb, txtc, txtd, txte, txtf, txtg, txtfai, txth, txtN, txtD4) VALUES (@txtaValue, @txtbValue, @txtcValue, @txtdValue, @txteValue, @txtfValue, @txtgValue, @txtfaiValue, @txthValue, @txtNValue, @txtD4Value)", connection))
                {
                    // 为 SQL 命令参数赋值，这样可以防止 SQL 注入攻击
                    cmd.Parameters.AddWithValue("@txtaValue", txtaValue);
                    cmd.Parameters.AddWithValue("@txtbValue", txtbValue);
                    cmd.Parameters.AddWithValue("@txtcValue", txtcValue);
                    cmd.Parameters.AddWithValue("@txtdValue", txtdValue);
                    cmd.Parameters.AddWithValue("@txteValue", txteValue);
                    cmd.Parameters.AddWithValue("@txtfValue", txtfValue);
                    cmd.Parameters.AddWithValue("@txtgValue", txtgValue);
                    cmd.Parameters.AddWithValue("@txtfaiValue", txtfaiValue);
                    cmd.Parameters.AddWithValue("@txthValue", txthValue);
                    cmd.Parameters.AddWithValue("@txtNValue", txtNValue);
                    cmd.Parameters.AddWithValue("@txtD4Value", txtD4Value);

                    // 执行 SQL 命令
                    cmd.ExecuteNonQuery();
                }

                // 关闭数据库连接
                connection.Close();
            }


        }








        private void pwarehouse_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtv1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
