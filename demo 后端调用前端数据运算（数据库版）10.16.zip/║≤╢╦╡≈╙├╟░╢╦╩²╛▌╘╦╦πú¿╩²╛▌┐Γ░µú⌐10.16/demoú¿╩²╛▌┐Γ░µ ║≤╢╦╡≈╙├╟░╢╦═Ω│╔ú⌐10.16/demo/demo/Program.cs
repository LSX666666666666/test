﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double sum = 0;
            int i = 0, j = 0;
            WareHouseCalculator ware=new WareHouseCalculator();
            List<(double x, double y)> coordinates = new List<(double x, double y)>();
            coordinates = ware.CalculateCoordinates();
            sum += ware.t1;
            double t1 = 4/ware.v1;
            double t2= 8/ware.v1;
            sum += t1;
            double t3 = 25.5 / ware.v2;
            sum += 100 * (ware.t2 + 2 * t3) ;//王淳
            //sum+=99*(ware.t2+2*t2+2*t3)+ware.t2+t2+t3;
            
            for (i=0;i < ware.row1; i++)
            {
                for (j=0; j < ware.columns1; j++)
                {
                    Console.Write("出库货物坐标为：");
                    Console.WriteLine(coordinates[j * ware.row1 + i]);                   
                }
            }
            for (i=0; i < ware.row1; i++)
            {
                for (j = 0; j < ware.columns2; j++)
                {
                    Console.Write("出库货物坐标为：");
                    Console.WriteLine(coordinates[j * ware.row1 + i]);
                }
            }
            for (i=0; i < ware.row2; i++)
            {
                for (j = 0; j < ware.columns1; j++)
                {
                    Console.Write("出库货物坐标为：");
                    Console.WriteLine(coordinates[j * ware.row1 + i]);
                }
            }
            for (i=0; i < ware.row2; i++)
            {
                for (j = 0; j < ware.columns2; j++)
                {
                    Console.Write("出库货物坐标为：");
                    Console.WriteLine(coordinates[j * ware.row1 + i]);
                }
            }
            Console.Write("总货物数量为：");
            Console.WriteLine(coordinates.Count);
            Console.Write("总时间为：");
            Console.WriteLine(sum);
        }

        public class WareHouseCalculator
        {
            public double a = 100.0; // 仓库长度
            public double b = 60.0; // 仓库宽度
            public double c = 40.0; //左侧宽
            public double d = 20.0; // 下册宽
            public double e = 2.0; //路宽
            public double f = 2.0; //与墙面间隔
            public double g = 2.0; //货物间隔
            public double fi = 2.0;//货物宽度
            public double h = 2.0; //货物高度

            public int car_num = 3;//车辆数量
            public int dyzj_num = 1;//

            public double v1 = 5 / 3.6;//吊运速度
            public double v2 = 10 / 3.6;//车运速度

            public double t1 = 20 * 60;//20分钟
            public double t2 = 5 * 60;

            public double car_len = 2;//车长不大于3米
            public int row1, columns2;
            public int columns1, row2;
            public WareHouseCalculator() { }
            public WareHouseCalculator(double a, double b, double c, double d, double e, double f, double g, double fi, double h, int car_num, int dyzj_num, double c_len)
            {
                // 使用默认参数，与前端页面连接后可修改为前端输入值
                this.a = a;
                this.b = b;
                this.c = c;
                this.d = d;
                this.e = e;
                this.f = f;
                this.g = g;
                this.fi = fi;
                this.h = h;
                this.car_num = car_num;
                this.dyzj_num = dyzj_num;
                this.car_len = c_len;
            }
            public List<(double x, double y)> CalculateCoordinates()
            {
                // 创建一个空的列表来存储坐标
                List<(double x, double y)> coordinates = new List<(double x, double y)>();

                // 确定货物的布局或分布方式
                // 这可能会根据具体的仓库布局和货物尺寸来决定
                // 在这个示例中，我们假设所有的货物都以一定的间隔平均分布在仓库中
                /*原计算：

                double c;//主路位置
                double d;//二路位置
                double e;//路宽

                int rows = (int)(a / (d + g));
                int columns = (int)(b / (d + g));
                */

                //修改更新：//1234
                int rows = (int)((c - 2 * f - e / 2) / (fi + g) + (a - c - 2 * f - e / 2) / (fi + g));
                int columns = (int)((d - 2 * f - e / 2) / (fi + g) + (b - d - 2 * f - e / 2) / (fi + g));
                // 计算每行和每列的货物的x和y坐标
                /*for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < columns; j++)
                    {
                        // 计算x和y坐标
                        double x = i * (fi + g) + fi / 2+f;
                        double y = j * (fi + g) + fi / 2 + f;

                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }
                }*/
                double x, y;
                int j = 0, i = 0;
                for (i = 0;; i++)
                {
                    x = i * (fi + g) + fi / 2 + f;
                    if (x > c - e / 2 - f - fi / 2)
                    {
                        this.columns1 = i;//列
                        break;
                    }
                    for (j = 0; ; j++)
                    {
                        // 计算x和y坐标

                        y = j * (fi + g) + fi / 2 + f;
                        if (y > b-d-f-e/2-fi/2)
                        {
                            this.row1 = j;//行
                            break;
                        }
                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }                    
                }
                for (i = 0; ; i++)
                {
                    x = i * (fi + g) + fi / 2 + f+c+e/2;
                    if (x > a-f-fi/2)
                    {
                        this.columns2 = i;
                        break;
                    }
                    for (j = 0; ; j++)
                    {
                        // 计算x和y坐标

                        y = j * (fi + g) + fi / 2 + f;
                        if (y > b - d - f - e / 2 - fi / 2)
                        {
                            this.row1 = j;
                            break;
                        }
                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }
                }
                for (i = 0; ; i++)
                {
                    x = i * (fi + g) + fi / 2 + f;
                    if (x > c - e / 2 - f - fi / 2)
                    {
                        this.columns1 = i;
                        break;
                    }
                    for (j = 0; ; j++)
                    {
                        // 计算x和y坐标

                        y = j * (fi + g) +b-d+e/2+f+fi/2;
                        if (y > b-f-fi/2)
                        {
                            this.row2 = j;
                            break;
                        }
                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }
                }
                for (i = 0; ; i++)
                {
                    x = i * (fi + g) + fi / 2 + f + c + e / 2;
                    if (x > a - f - fi / 2)
                    {
                        this.columns2 = i;
                        break;
                    }
                    for (j = 0; ; j++)
                    {
                        // 计算x和y坐标

                        y = j * (fi + g) + b - d + e / 2 + f + fi / 2;
                        if (y > b - f - fi / 2)
                        {
                            this.row2 = j;
                            break;
                        }
                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }
                }
                // 返回坐标列表
                return coordinates;
            }

        }
    }
}
