﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Data.SqlClient;


//运行前必看
//首先记得去修改自己文件夹的的路径
//找到自己电脑的路径，找到前端数据保存.txt，修改路径变量filePath

namespace demo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WareHouseCalculator ware=new WareHouseCalculator();


            // 指定要读取的文件路径
            // 获取当前应用程序域的基本目录
            // string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            // 构建相对路径
            //string relativePath = @"前端数据保存到TXT完成10.11\前端页面修改\warehouse\bin\Debug\前端数据保存.txt";
            // 合并基本目录和相对路径以获取完整路径
            //string filePath = Path.Combine(baseDirectory, relativePath);


            //运行前必看
            //首先记得去修改自己文件夹的的路径
            //找到自己电脑的路径，找到前端数据保存.txt
            /*
            string filePath = @"C:\Users\h3854\Desktop\前后端交互（文件读取版）10.13\前端数据保存到TXT完成10.11\前端页面修改\warehouse\bin\Debug\前端数据保存.txt";

            Console.Write(filePath);

            if (File.Exists(filePath))
            {
                try
                {
                    // 创建 WareHouseCalculator 对象
                    //WareHouseCalculator ware = new WareHouseCalculator();

                    // 读取文件内容
                    string[] lines = File.ReadAllLines(filePath);

                    // 遍历文件中的每一行
                    foreach (string line in lines)
                    {
                        // 切分每一行，以冒号为分隔符
                        string[] parts = line.Split(':');
                        if (parts.Length == 2)
                        {
                            // 获取属性名和属性值
                            string propertyName = parts[0].Trim();
                            string propertyValue = parts[1].Trim();

                            // 根据属性名设置相应的变量值
                            switch (propertyName)
                            {
                                case "txta":
                                    ware.a = double.Parse(propertyValue);
                                    break;
                                case "txtb":
                                    ware.b = double.Parse(propertyValue);
                                    break;
                                case "txtc":
                                    ware.c = double.Parse(propertyValue);
                                    break;
                                case "txtd":
                                    ware.d = double.Parse(propertyValue);
                                    break;
                                case "txte":
                                    ware.e = double.Parse(propertyValue);
                                    break;
                                case "txtf":
                                    ware.f = double.Parse(propertyValue);
                                    break;
                                case "txtg":
                                    ware.g = double.Parse(propertyValue);
                                    break;
                                case "txtfai":
                                    ware.fi = double.Parse(propertyValue);
                                    break;
                                case "txth":
                                    ware.h = double.Parse(propertyValue);
                                    break;
                                default:
                                    // 可以处理未知属性名的情况，或者忽略它们
                                    break;
                            }
                        }
                    }

                    // 打印读取的值
                    Console.WriteLine("txta: " + ware.a);

                    // 以此类推，打印其他变量

                    // 接下来可以执行你的计算逻辑
                }
                catch (Exception ex)
                {
                    Console.WriteLine("读取文件时出错: " + ex.Message);
                }
            }
            else
            {
                Console.WriteLine("文件 " + filePath + " 不存在。");
            }
            */

            /*cartime car=new cartime(ware);
            
            car.carouttime();*///计算车出库时间点


            string connStr = "server=127.0.0.1;database=date3;user=admin4;password=123456";

          
            using (MySql.Data.MySqlClient.MySqlConnection conn = new MySql.Data.MySqlClient.MySqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT txta, txtb, txtc, txtd, txte, txtf, txtg, txth FROM date3";
                    MySql.Data.MySqlClient.MySqlCommand cmd = new MySql.Data.MySqlClient.MySqlCommand(query, conn);
                    MySql.Data.MySqlClient.MySqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        ware.a = reader.GetDouble("txta");
                        ware.b = reader.GetDouble("txtb");
                        ware.c = reader.GetDouble("txtc");
                        ware.d = reader.GetDouble("txtd");
                        ware.e = reader.GetDouble("txte");
                        ware.f = reader.GetDouble("txtf");
                        ware.g = reader.GetDouble("txtg");
                        ware.h = reader.GetDouble("txth");

                    }
                    reader.Close();
                    Console.WriteLine("数据库操作 " );
                }
                catch (Exception ex)
                {
                    Console.WriteLine("数据库操作出错: " + ex.Message);
                }
            }



            DYZJ dYZG =new DYZJ(ware);

            dYZG.DYZJtime();

            Console.ReadKey(); // 等待用户按下一个键
        }

        public class WareHouseCalculator
        {
            public double a = 100.0; // 仓库长度
            public double b = 60.0; // 仓库宽度
            public double c = 40.0; //左侧宽
            public double d = 20.0; // 下册宽
            public double e = 2.0; //路宽
            public double f = 2.0; //与墙面间隔
            public double g = 2.0; //货物间隔
            public double fi = 2.0;//货物宽度
            public double h = 2.0; //货物高度
            
            public int car_num = 3;//车辆数量
            public int dyzj_num = 1;//

            public double v1 = 5 / 3.6;//吊运速度
            public double v2 = 10 / 3.6;//车运速度

            public double t1 = 20 * 60;//20分钟
            public double t2 = 5 * 60;

            public double car_len = 2;//车长不大于3米
            public int row1, columns2;
            public int columns1, row2;

            public double centerx= 40;//记录中心点坐标
            public double centery = 40;

            public WareHouseCalculator() { }
            public WareHouseCalculator(double a, double b, double c, double d, double e, double f, double g, double fi, double h, int car_num, int dyzj_num, double c_len)
            {
                // 使用默认参数，与前端页面连接后可修改为前端输入值
                this.a = a;
                this.b = b;
                this.c = c;
                this.d = d;
                this.e = e;
                this.f = f;
                this.g = g;
                this.fi = fi;
                this.h = h;
                this.car_num = car_num;
                this.dyzj_num = dyzj_num;
                this.car_len = c_len;
            }
            public double Time(double targetX, double targetY)//有毛病
            {
                // 计算曼哈顿距离
                double distance = Math.Abs(targetX - centerx) + Math.Abs(targetY - centery);
                // 返回到目标位置所需的时间，假设速度为 v
                return distance / v1;
            }
            public List<(double x, double y)> CalculateCoordinates()
            {
                // 创建一个空的列表来存储坐标
                List<(double x, double y)> coordinates = new List<(double x, double y)>();

                // 确定货物的布局或分布方式
                // 这可能会根据具体的仓库布局和货物尺寸来决定
                // 在这个示例中，我们假设所有的货物都以一定的间隔平均分布在仓库中
                /*原计算：

                double c;//主路位置
                double d;//二路位置
                double e;//路宽

                int rows = (int)(a / (d + g));
                int columns = (int)(b / (d + g));
                */

                //修改更新：//1234
                int rows = (int)((c - 2 * f - e / 2) / (fi + g) + (a - c - 2 * f - e / 2) / (fi + g));
                int columns = (int)((d - 2 * f - e / 2) / (fi + g) + (b - d - 2 * f - e / 2) / (fi + g));
                // 计算每行和每列的货物的x和y坐标
                /*for (int i = 0; i < rows; i++)
                {
                    for (int j = 0; j < columns; j++)
                    {
                        // 计算x和y坐标
                        double x = i * (fi + g) + fi / 2+f;
                        double y = j * (fi + g) + fi / 2 + f;

                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }
                }*/
                double x, y;
                int j = 0, i = 0;
                for (i = 0;; i++)
                {
                    x = i * (fi + g) + fi / 2 + f;
                    if (x > c - e / 2 - f - fi / 2)
                    {
                        this.columns1 = i;//列
                        break;
                    }
                    for (j = 0; ; j++)
                    {
                        // 计算x和y坐标

                        y = j * (fi + g) + fi / 2 + f;
                        if (y > b-d-f-e/2-fi/2)
                        {
                            this.row1 = j;//行
                            break;
                        }
                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }                    
                }
                for (i = 0; ; i++)
                {
                    x = i * (fi + g) + fi / 2 + f+c+e/2;
                    if (x > a-f-fi/2)
                    {
                        this.columns2 = i;
                        break;
                    }
                    for (j = 0; ; j++)
                    {
                        // 计算x和y坐标

                        y = j * (fi + g) + fi / 2 + f;
                        if (y > b - d - f - e / 2 - fi / 2)
                        {
                            this.row1 = j;
                            break;
                        }
                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }
                }
                for (i = 0; ; i++)
                {
                    x = i * (fi + g) + fi / 2 + f;
                    if (x > c - e / 2 - f - fi / 2)
                    {
                        this.columns1 = i;
                        break;
                    }
                    for (j = 0; ; j++)
                    {
                        // 计算x和y坐标

                        y = j * (fi + g) +b-d+e/2+f+fi/2;
                        if (y > b-f-fi/2)
                        {
                            this.row2 = j;
                            break;
                        }
                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }
                }
                for (i = 0; ; i++)
                {
                    x = i * (fi + g) + fi / 2 + f + c + e / 2;
                    if (x > a - f - fi / 2)
                    {
                        this.columns2 = i;
                        break;
                    }
                    for (j = 0; ; j++)
                    {
                        // 计算x和y坐标

                        y = j * (fi + g) + b - d + e / 2 + f + fi / 2;
                        if (y > b - f - fi / 2)
                        {
                            this.row2 = j;
                            break;
                        }
                        // 将坐标添加到列表中
                        coordinates.Add((x, y));
                    }
                }
                // 返回坐标列表
                return coordinates;
            }

        }
        public class cargo 
        {
            public double targetx1=36;
            public double targety1 =44;
            public double targetx2 =36 ;
            public double targety2 = 36;
            public double targetx3=44;
            public double targety3=36;

            public bool stuate;
            public double x;
            public double y;
            public double time;
            public cargo(bool stuate, double x,double y, double time)
            {
                this.stuate = stuate;
               this.x = x;
                this.y = y;
                this.time = time;
            }          
        }
        public class cargos
        {
           public cargo[] cargo=new cargo[299];
            public double num;
           public cargos(WareHouseCalculator ware)
            {
                List<(double x, double y)> coordinates = new List<(double x, double y)>();
                coordinates = ware.CalculateCoordinates();
                this.num= coordinates.Count;
                for(int i=0;i<coordinates.Count;i++)
                {
                    double time = ware.Time(coordinates[i].x, coordinates[i].y);
                    double x = coordinates[i].x;
                    double y = coordinates[i].y;
                    cargo car = new cargo(true, x, y, time);
                    this.cargo[i] = car;
                }
            }
        }
      public class cartime
        {
            public double targetx1 = 35;
            public double targety1 = 40;
            public double targetx2 = 40;
            public double targety2 = 25;
            public double targetx3 = 45;
            public double targety3 = 40;
            public double v2;
            WareHouseCalculator ware;
            public cartime(WareHouseCalculator ware)
            {
                this.v2= ware.v2;
                this.ware = ware;
            }
            public void carouttime()//数学方法算出各个车出库时间点
            {
                double sum = 0;
                sum += ware.t1;
                double t1 = 4 / ware.v1;
                double t2 = 25 / ware.v2;
                sum += t1;
                sum+= ware.t2;
                List<(double x, double y)> coordinates = new List<(double x, double y)>();
                coordinates = ware.CalculateCoordinates();
                Console.WriteLine("1," + sum);
                for (int i = 1; i < coordinates.Count-1; i++)
                {
                    if(i%3==0)
                    {
                        sum += ware.t2+2*t2;
                        Console.WriteLine("1," + sum);
                    }
                    if(i%3==1)
                    {
                        Console.WriteLine("2," + (sum + 2*t2));//有问题最后一次不用+2*t2
                    }
                    if(i%3==2)
                    {
                        Console.WriteLine("3,"+(sum+4*t2));
                    }
                }
            }
        }
        public class DYZJ
        {
            WareHouseCalculator ware;
            public double x;
            public double y;//坐标，很熟悉了
            public double v1;//速度
            cargos cargos;
            cartime cartime;
            public DYZJ(WareHouseCalculator wc)
            {
                this.ware = wc;
                this.x = 36;
                this.y = 44;//可以写的具有泛化性
                this.v1 = wc.v1;
                cargos cargos = new cargos(wc);
                this.cargos = cargos;
                cartime cartime=new cartime(wc);
                this.cartime = cartime;
            }
            public double Time(double x1, double y1, double x2, double y2)
            {
                double distance = Math.Abs(x1- x2) + Math.Abs(y1 - y2);
                double time = distance / v1;
                return time;
            }
            public void DYZJtime()//最后一次的情况没考虑，目前结果对，但最后一次吊具可能有点奇怪
            {
                double sum = 0;
                double sum2 = 0;
                sum += ware.t1;
                double t2 = 25 / ware.v2;
                int p= 1;
                sum += 4 / v1;//到达车1的时间，可以用参数代替
                List<(double x, double y)> coordinates = new List<(double x, double y)>();
                coordinates = ware.CalculateCoordinates();
                double sum1 = sum+ware.t2+2*t2;
                for (int i = 0; i < coordinates.Count / 3; i++)
                {
                    double min = 9999;//方便找最小值，应该有更好的办法
                    double max = 0;//方便找最大值
                    int k = 0;
                    Console.WriteLine(cartime.targetx1 + " " + cartime.targety1);//从最近货物到车目标点1(默认第一次在货物目标点1)
                    if(p!=1)
                    {
                        Console.WriteLine(sum1-sum);//计算等待时间
                        sum = sum1;
                        sum1=sum+ware.t2+2*t2;
                    }
                    sum += 4 / v1;
                    Console.WriteLine( cargos.cargo[0].targetx2 + " " + cargos.cargo[0].targety2);//到货目标点2
                    sum += 4 / v1;
                    Console.WriteLine( cartime.targetx2 + " " + cartime.targety2);//到车目标点2
                    if (p != 1)
                    {
                        sum += 2 * t2 - 8 / v1;
                    }
                    sum += 4 / v1;
                    Console.WriteLine(cargos.cargo[0].targetx3 + " " + cargos.cargo[0].targety3);//到货目标点3
                    sum += 4 / v1;
                    Console.WriteLine(cartime.targetx3 + " " + cartime.targety3);//到车目标点3
                    if (p != 1)
                    {
                        sum += 2 * t2 - 8 / v1;
                    }
                    p = 2;
                    for (int j = 0; cargos.cargo.Length > j; j++)//找到最远距离
                    {
                        if (cargos.cargo[j].stuate != false)
                        {
                            if (cargos.cargo[j].time >= max)
                            {
                                max = cargos.cargo[j].time;
                                k = j;
                            }
                        }
                    }
                    cargos.cargo[k].stuate = false;//设置状态为false
                    sum += Time(cartime.targetx3, cartime.targety3, cargos.cargo[k].x, cargos.cargo[k].y);
                    Console.WriteLine(cargos.cargo[k].x + " " + cargos.cargo[k].y);//过程是连贯的，从车目标点3到最远货物
                    sum += Time(cargos.cargo[k].x, cargos.cargo[k].y, cargos.cargo[0].targetx2, cargos.cargo[0].targety2);
                    Console.WriteLine(cargos.cargo[0].targetx2 + " " + cargos.cargo[0].targety2);//转运过程：从最远货物到货物目标点2
                    max = 0;
                    for (int j = 0; cargos.cargo.Length > j; j++)//找到最远距离
                    {
                        if (cargos.cargo[j].stuate != false)
                        {
                            if (cargos.cargo[j].time >= max)
                            {
                                max = cargos.cargo[j].time;
                                k = j;
                            }
                        }
                    }
                    cargos.cargo[k].stuate = false;
                    sum += Time(cargos.cargo[0].targetx2, cargos.cargo[0].targety2, cargos.cargo[k].x, cargos.cargo[k].y);
                    Console.WriteLine(cargos.cargo[k].x + " " + cargos.cargo[k].y);//从货目标点2到最远货物
                    sum += Time(cargos.cargo[k].x, cargos.cargo[k].y, cargos.cargo[0].targetx3, cargos.cargo[0].targety3);
                    Console.WriteLine( cargos.cargo[0].targetx3 + " " + cargos.cargo[0].targety3);//转运过程：从最远货物到货物目标点3
                    for (int j = 0; cargos.cargo.Length > j; j++)//找到最近距离
                    {
                        if (cargos.cargo[j].stuate != false)
                        {
                            if (cargos.cargo[j].time <= min)
                            {
                                min = cargos.cargo[j].time;
                                k = j;
                            }
                        }
                    }
                    cargos.cargo[k].stuate = false;
                    sum += Time(cargos.cargo[0].targetx3, cargos.cargo[0].targetx3, cargos.cargo[k].x, cargos.cargo[k].y);
                    Console.WriteLine(cargos.cargo[k].x + " " + cargos.cargo[k].y);//从货物目标点3到最近货物
                    sum += Time(cargos.cargo[k].x, cargos.cargo[k].y, cartime.targetx1, cartime.targety1);
                }
            }
        }

        
    }
}
